#pragma once
#include "common.cuh"

// BF16 layouts are independent from the A100 TF32 code. A row has at least
// eight 16-byte chunks so the XOR maps eight rows to distinct bank groups.
template<int BM,int BN,int BK,int WM,int WN,int STAGES,bool ASYNC,bool DOUBLE,int EPI=0,int COPY=0,int ORDER=0>
__global__ __launch_bounds__((BM/WM)*(BN/WN)*32)
void bf16Pipeline(Problem p, int group) {
  constexpr int THREADS=(BM/WM)*(BN/WN)*32, LA=BK<64?64:BK;
  constexpr int AS=BM*LA,BS=BK*BN,MF=WM/16,NF=WN/8,KS=BK/16;
  extern __shared__ __align__(128) __nv_bfloat16 sm[];
  auto as=sm; auto bs=sm+STAGES*AS;
  int bx=blockIdx.x,by=blockIdx.y;
  if(group>0) {
    int linear=by*gridDim.x+bx, per=group*gridDim.x, first=linear/per*group;
    int rows=min(int(gridDim.y)-first,group);
    by=first+(linear%per)%rows; bx=(linear%per)/rows;
  }
  const int tid=threadIdx.x, lane=tid%32, warp=tid/32;
  const int wr=warp/(BN/WN)*WM,wc=warp%(BN/WN)*WN;
  const auto ag=p.a+by*BM*p.k;
  const auto bg=p.b+bx*BN;
  const auto cg=p.c+by*BM*p.n+bx*BN;
  auto dg=p.d+by*BM*p.n+bx*BN;
  auto ax=[] __device__ (int r,int c) { return r*LA+(c^((r&7)*8)); };
  auto bxoff=[] __device__ (int r,int c) { return r*BN+(c^((r&7)*8)); };
  auto copy_tile=[&](int stage,int tile,int part=-1) {
    auto ad=as+stage*AS; auto bd=bs+stage*BS;
#pragma unroll
    for(int j=0;j<(BM*BK/8+THREADS-1)/THREADS;++j) {
      int i=tid+j*THREADS;
      if(i<BM*BK/8 && (part<0 || j%KS==part)) {
        int r=i/(BK/8),c=i%(BK/8)*8;
        auto src=ag+r*p.k+tile*BK+c; auto dst=ad+ax(r,c);
        if constexpr(ASYNC) cp16(dst,src);
        else reinterpret_cast<uint4*>(dst)[0]=reinterpret_cast<const uint4*>(src)[0];
      }
    }
#pragma unroll
    for(int j=0;j<(BK*BN/8+THREADS-1)/THREADS;++j) {
      int i=tid+j*THREADS;
      if(i<BK*BN/8 && (part<0 || j%KS==part)) {
        int r,c;
        if constexpr(COPY==2) {
          constexpr int CH=THREADS/BK;
          r=tid/CH; c=(tid%CH+j*CH)*8;
        } else { r=i/(BN/8); c=i%(BN/8)*8; }
        auto src=bg+(tile*BK+r)*p.n+c; auto dst=bd+bxoff(r,c);
        if constexpr(ASYNC) cp16(dst,src);
        else reinterpret_cast<uint4*>(dst)[0]=reinterpret_cast<const uint4*>(src)[0];
      }
    }
  };
  float acc[MF][NF][4]={};
  unsigned af[DOUBLE?2:1][MF][4],bf[DOUBLE?2:1][NF][2];
  auto load=[&](int buf,int stage,int step) {
    auto a=as+stage*AS; auto b=bs+stage*BS;
    int ar=wr+(lane&15),ac=step*16+(lane/16)*8;
#pragma unroll
    for(int m=0;m<MF;++m) ldm_a(af[buf][m],a+ax(ar+m*16,ac));
    int br=step*16+(lane&15);
#pragma unroll
    for(int n=0;n<NF;++n) ldm_b(bf[buf][n],b+bxoff(br,wc+n*8));
  };
  auto compute=[&](int buf) {
#pragma unroll
    for(int m=0;m<MF;++m)
#pragma unroll
      for(int n0=0;n0<NF;++n0) {
        int n=ORDER && (m&1)?NF-1-n0:n0;
        mma_bf16(acc[m][n],af[buf][m],bf[buf][n]);
      }
  };
  const int tiles=p.k/BK;
  if constexpr(ASYNC) {
#pragma unroll
    for(int s=0;s<STAGES-1;++s) { if(s<tiles) copy_tile(s,s); commit(); }
  }
  for(int tile=0;tile<tiles;++tile) {
    int stage=tile%STAGES,next=tile+STAGES-1;
    if constexpr(ASYNC) wait<STAGES-2>();
    else copy_tile(0,tile);
    __syncthreads();
    if constexpr(ASYNC && COPY==0) { if(next<tiles) copy_tile(next%STAGES,next); commit(); }
    if constexpr(DOUBLE) load(0,stage,0);
#pragma unroll
    for(int step=0;step<KS;++step) {
      if constexpr(ASYNC && COPY!=0) { if(next<tiles) copy_tile(next%STAGES,next,step); }
      if constexpr(DOUBLE) {
        if(step+1<KS) load((step+1)%2,stage,step+1);
        compute(step%2);
      } else { load(0,stage,step); compute(0); }
    }
    if constexpr(ASYNC && COPY!=0) commit();
    if constexpr(!ASYNC) __syncthreads();
  }
  if constexpr(ASYNC) wait<0>();
  if constexpr(EPI==0) {
#pragma unroll
    for(int m=0;m<MF;++m)
#pragma unroll
      for(int n=0;n<NF;++n) {
        int row=wr+m*16+lane/4,col=wc+n*8+(lane%4)*2;
#pragma unroll
        for(int h=0;h<2;++h) {
          int off=(row+h*8)*p.n+col;
          float2 c=reinterpret_cast<const float2*>(cg+off)[0];
          reinterpret_cast<float2*>(dg+off)[0]=make_float2(p.alpha*acc[m][n][2*h]+p.beta*c.x,p.alpha*acc[m][n][2*h+1]+p.beta*c.y);
        }
      }
  } else {
    __syncthreads();
    // Reuse the input staging allocation for a bank-padded FP32 output tile.
    constexpr int LD=BN+4;
    float *out=reinterpret_cast<float*>(sm);
#pragma unroll
    for(int m=0;m<MF;++m)
#pragma unroll
      for(int n=0;n<NF;++n) {
        int row=wr+m*16+lane/4,col=wc+n*8+(lane%4)*2;
        reinterpret_cast<float2*>(out+row*LD+col)[0]=make_float2(acc[m][n][0],acc[m][n][1]);
        reinterpret_cast<float2*>(out+(row+8)*LD+col)[0]=make_float2(acc[m][n][2],acc[m][n][3]);
      }
    __syncthreads();
#pragma unroll
    for(int base=0;base<BM*BN/4;base+=THREADS*EPI) {
      float4 cv[EPI];
#pragma unroll
      for(int j=0;j<EPI;++j) {
        int i=base+tid+j*THREADS;
        if(i<BM*BN/4) cv[j]=reinterpret_cast<const float4*>(cg+(i/(BN/4))*p.n+(i%(BN/4))*4)[0];
      }
#pragma unroll
      for(int j=0;j<EPI;++j) {
        int i=base+tid+j*THREADS;
        if(i<BM*BN/4) {
          int row=i/(BN/4),col=i%(BN/4)*4;
          float4 v=reinterpret_cast<const float4*>(out+row*LD+col)[0],c=cv[j];
          v.x=p.alpha*v.x+p.beta*c.x; v.y=p.alpha*v.y+p.beta*c.y;
          v.z=p.alpha*v.z+p.beta*c.z; v.w=p.alpha*v.w+p.beta*c.w;
          reinterpret_cast<float4*>(dg+row*p.n+col)[0]=v;
        }
      }
    }
  }
}
