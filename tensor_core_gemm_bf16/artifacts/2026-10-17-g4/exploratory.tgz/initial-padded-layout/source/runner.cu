#include "runner.cuh"
#include "kernels/basics.cuh"
#include "kernels/pipeline.cuh"
#include <algorithm>
#include <limits>

static void simt(const Problem& p,cudaStream_t s,int) { bf16Simt<<<dim3(p.n/16,p.m/16),dim3(16,16),0,s>>>(p); }
static void wmma(const Problem& p,cudaStream_t s,int) { bf16WmmaNaive<<<dim3(p.n/32,p.m/32),128,0,s>>>(p); }
static void wmma_smem(const Problem& p,cudaStream_t s,int) { bf16WmmaSmem<<<dim3(p.n/64,p.m/64),128,0,s>>>(p); }

template<int BM,int BN,int BK,int WM,int WN,int S,bool A,bool D,int E=0,int C=0,int O=0>
constexpr int shared_bytes() {
  constexpr int input=S*(BM*(BK<64?64:BK)+BK*BN)*2;
  return E?std::max(input,BM*(BN+4)*4):input;
}
template<int BM,int BN,int BK,int WM,int WN,int S,bool A,bool D,int E=0,int C=0,int O=0>
static void pipeline(const Problem& p,cudaStream_t stream,int group) {
  constexpr int bytes=shared_bytes<BM,BN,BK,WM,WN,S,A,D,E,C,O>();
  auto fn=bf16Pipeline<BM,BN,BK,WM,WN,S,A,D,E,C,O>;
  static bool configured=false;
  if(!configured) { ck(cudaFuncSetAttribute(fn,cudaFuncAttributeMaxDynamicSharedMemorySize,bytes)); configured=true; }
  fn<<<dim3(p.n/BN,p.m/BM),(BM/WM)*(BN/WN)*32,bytes,stream>>>(p,group);
}
const std::vector<Variant>& variants() {
  static const std::vector<Variant> all=[] {
    std::vector<Variant> v{
      {"s0_simt",0,16,16,16,0,256,simt},
      {"s1_wmma_global",1,32,32,16,0,128,wmma},
      {"s2_wmma_smem",2,64,64,32,8192,128,wmma_smem}};
#define ADD(NAME,ST,BM,BN,BK,WM,WN,S,A,D,E,C,O) \
    v.push_back({NAME,ST,BM,BN,BK,shared_bytes<BM,BN,BK,WM,WN,S,A,D,E,C,O>(),(BM/WM)*(BN/WN)*32,pipeline<BM,BN,BK,WM,WN,S,A,D,E,C,O>});
    ADD("s3_mma_ldmatrix",3,128,128,32,64,32,1,false,false,0,0,0)
    ADD("s4_async",4,128,128,32,64,32,3,true,false,0,0,0)
    ADD("s5_frag_double",5,128,128,32,64,32,3,true,true,0,0,0)
#define TILE(BM,BN,BK,WM,WN,S) \
    ADD("t" #BM "x" #BN "k" #BK "s" #S,6,BM,BN,BK,WM,WN,S,true,true,0,0,0)
    TILE(64,64,32,32,32,2) TILE(64,64,32,32,32,3) TILE(64,64,32,32,32,4)
    TILE(64,128,32,32,64,2) TILE(64,128,32,32,64,3) TILE(64,128,32,32,64,4)
    TILE(128,64,32,64,32,2) TILE(128,64,32,64,32,3) TILE(128,64,32,64,32,4)
    TILE(128,128,32,64,32,2) TILE(128,128,32,64,32,4)
    TILE(128,128,32,64,64,2) TILE(128,128,32,64,64,3)
    TILE(128,256,32,64,64,2) TILE(128,256,32,64,64,3)
    TILE(256,128,32,64,64,2) TILE(256,128,32,64,64,3)
    TILE(64,64,64,32,32,2) TILE(64,64,64,32,32,3) TILE(64,64,64,32,32,4)
    TILE(64,128,64,32,64,2) TILE(64,128,64,32,64,3)
    TILE(128,64,64,64,32,2) TILE(128,64,64,64,32,3)
    TILE(128,128,64,64,32,2) TILE(128,128,64,64,32,3)
    TILE(128,256,64,64,64,2) TILE(256,128,64,64,64,2)
#define FINAL(NAME,BM,BN,BK,WM,WN,S,E,C,O) ADD(NAME,6,BM,BN,BK,WM,WN,S,true,true,E,C,O)
    FINAL("f64_epi1",64,64,32,32,32,3,1,0,0)
    FINAL("f64_epi4",64,64,32,32,32,3,4,0,0)
    FINAL("f64_dist",64,64,32,32,32,3,4,1,0)
    FINAL("f64_rake",64,64,32,32,32,3,4,2,1)
    FINAL("f128_epi1",128,128,32,64,32,3,1,0,0)
    FINAL("f128_epi4",128,128,32,64,32,3,4,0,0)
    FINAL("f128_dist",128,128,32,64,32,3,4,1,0)
    FINAL("f128_rake",128,128,32,64,32,3,4,2,1)
    FINAL("f128_rake64",128,128,64,64,32,2,4,2,1)
    FINAL("f128_w64",128,128,32,64,64,3,4,2,1)
    FINAL("f128x256_dist",128,256,32,64,64,3,0,1,1)
    FINAL("f128x256_rake",128,256,32,64,64,3,0,2,1)
    FINAL("f256x128_dist",256,128,32,64,64,3,0,1,1)
    FINAL("f256x128_rake",256,128,32,64,64,3,0,2,1)
#undef FINAL
#undef TILE
#undef ADD
    return v;
  }();
  return all;
}

void run(const Variant& v,const Problem& p,cudaStream_t stream,int group) {
  if(p.m<=0||p.n<=0||p.k<=0||p.m%v.bm||p.n%v.bn||p.k%v.bk||group<0)
    throw std::invalid_argument("shape incompatible with " + v.name);
  v.launch(p,stream,group); ck(cudaGetLastError());
}
void reference(cublasHandle_t handle,const Problem& p,const float *af,const float *bf) {
  cb(cublasSetMathMode(handle,CUBLAS_PEDANTIC_MATH));
  ck(cudaMemcpy(p.d,p.c,size_t(p.m)*p.n*sizeof(float),cudaMemcpyDeviceToDevice));
  cb(cublasGemmEx(handle,CUBLAS_OP_N,CUBLAS_OP_N,p.n,p.m,p.k,&p.alpha,
      bf,CUDA_R_32F,p.n,af,CUDA_R_32F,p.k,&p.beta,p.d,CUDA_R_32F,p.n,
      CUBLAS_COMPUTE_32F_PEDANTIC,CUBLAS_GEMM_DEFAULT));
}
Library::Library(const Problem& p) {
  cb(cublasLtCreate(&handle));
  cb(cublasLtMatmulDescCreate(&desc,CUBLAS_COMPUTE_32F,CUDA_R_32F));
  // Row-major D^T=B^T A^T: no transpose or conversion inside the timed region.
  cb(cublasLtMatrixLayoutCreate(&al,CUDA_R_16BF,p.n,p.k,p.n));
  cb(cublasLtMatrixLayoutCreate(&bl,CUDA_R_16BF,p.k,p.m,p.k));
  cb(cublasLtMatrixLayoutCreate(&cl,CUDA_R_32F,p.n,p.m,p.n));
  cb(cublasLtMatrixLayoutCreate(&dl,CUDA_R_32F,p.n,p.m,p.n));
  ck(cudaMalloc(&workspace,workspace_size));
  cublasLtMatmulPreference_t pref;
  cb(cublasLtMatmulPreferenceCreate(&pref));
  cb(cublasLtMatmulPreferenceSetAttribute(pref,CUBLASLT_MATMUL_PREF_MAX_WORKSPACE_BYTES,&workspace_size,sizeof(workspace_size)));
  cublasLtMatmulHeuristicResult_t choices[32]; int count=0;
  cb(cublasLtMatmulAlgoGetHeuristic(handle,desc,al,bl,cl,dl,pref,32,choices,&count));
  cb(cublasLtMatmulPreferenceDestroy(pref));
  if(!count) throw std::runtime_error("No cuBLASLt BF16/FP32 algorithm");
  cudaEvent_t start,end; ck(cudaEventCreate(&start)); ck(cudaEventCreate(&end));
  float best=std::numeric_limits<float>::infinity();
  cublasLtMatmulAlgo_t best_algorithm=choices[0].algo;
  for(int i=0;i<count;++i) {
    if(choices[i].state!=CUBLAS_STATUS_SUCCESS) continue;
    algorithm=choices[i].algo;
    launch(p); ck(cudaEventRecord(start));
    for(int j=0;j<10;++j) launch(p);
    ck(cudaEventRecord(end));ck(cudaEventSynchronize(end));
    float ms;ck(cudaEventElapsedTime(&ms,start,end));
    if(ms<best) {best=ms;best_algorithm=choices[i].algo;}
  }
  algorithm=best_algorithm;
  ck(cudaEventDestroy(start));ck(cudaEventDestroy(end));
}
void Library::launch(const Problem& p,cudaStream_t stream) const {
  cb(cublasLtMatmul(handle,desc,&p.alpha,p.b,al,p.a,bl,&p.beta,p.c,cl,p.d,dl,&algorithm,workspace,workspace_size,stream));
}
Library::~Library() {
  cudaFree(workspace);
  cublasLtMatrixLayoutDestroy(al);cublasLtMatrixLayoutDestroy(bl);
  cublasLtMatrixLayoutDestroy(cl);cublasLtMatrixLayoutDestroy(dl);
  cublasLtMatmulDescDestroy(desc);cublasLtDestroy(handle);
}
